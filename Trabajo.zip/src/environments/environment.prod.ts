export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyALzKahfkKaPpTYJSd3FlnsXjlddk_NgCI",
    authDomain: "pmovil-53d30.firebaseapp.com",
    projectId: "pmovil-53d30",
    storageBucket: "pmovil-53d30.appspot.com",
    messagingSenderId: "577580537999",
    appId: "1:577580537999:web:b366da04ba2c040c95b8fa"
  }
};
