// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyALzKahfkKaPpTYJSd3FlnsXjlddk_NgCI",
    authDomain: "pmovil-53d30.firebaseapp.com",
    projectId: "pmovil-53d30",
    storageBucket: "pmovil-53d30.appspot.com",
    messagingSenderId: "577580537999",
    appId: "1:577580537999:web:b366da04ba2c040c95b8fa"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
